/**
 * OpenCL利用クラスのパッケージ
 */
package para.opencl;
