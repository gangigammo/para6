package para.graphic.parser;
import java.util.*;

interface MetaParser{
  void parse(Scanner s);
}
