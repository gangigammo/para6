package para;
/** スライダにより画像処理効果が変わるプログラム
 */
public class Main19 extends Main15{
    public Main19(){ super("imagefilter.cl", "Filter5");}

    public Main19(String filename, String kernelname){super(filename,kernelname);}
}