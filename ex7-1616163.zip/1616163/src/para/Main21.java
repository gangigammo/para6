package para;
/** スライダにより画像処理効果が変わるプログラム
 */
public class Main21 extends Main15{
    public Main21(){ super("imagefilter.cl", "Filter7");}

    public Main21(String filename, String kernelname){super(filename,kernelname);}
}