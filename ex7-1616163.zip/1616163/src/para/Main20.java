package para;
/** スライダにより画像処理効果が変わるプログラム
 */
public class Main20 extends Main15{
    public Main20(){ super("imagefilter.cl", "Filter6");}

    public Main20(String filename, String kernelname){super(filename,kernelname);}
}